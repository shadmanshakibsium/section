/* ===========================
   ShopZone - main.js
   Minimal JS — Bootstrap handles most UI
   =========================== */

/* --- Cart Count (LocalStorage) --- */
function getCart() {
  return JSON.parse(localStorage.getItem('shopzone_cart') || '[]');
}

function saveCart(cart) {
  localStorage.setItem('shopzone_cart', JSON.stringify(cart));
}

function updateCartBadge() {
  const cart = getCart();
  const total = cart.reduce(function (sum, item) { return sum + item.qty; }, 0);
  document.querySelectorAll('.cart-count').forEach(function (el) {
    el.textContent = total;
    el.classList.toggle('d-none', total === 0);
  });
}

/* --- Add to Cart --- */
function addToCart(id, name, price, img) {
  var cart = getCart();
  var existing = cart.find(function (i) { return i.id === id; });
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ id: id, name: name, price: price, img: img, qty: 1 });
  }
  saveCart(cart);
  updateCartBadge();
  showToast(name + ' added to cart!');
}

/* --- Toast Notification --- */
function showToast(msg) {
  var toastEl = document.getElementById('cartToast');
  if (!toastEl) return;
  document.getElementById('toastMsg').textContent = msg;
  var toast = new bootstrap.Toast(toastEl, { delay: 2500 });
  toast.show();
}

/* --- Render Cart Page --- */
function renderCart() {
  var container = document.getElementById('cartItemsContainer');
  var summaryTotal = document.getElementById('summaryTotal');
  var summarySubtotal = document.getElementById('summarySubtotal');
  if (!container) return;

  var cart = getCart();

  if (cart.length === 0) {
    container.innerHTML = '<div class="text-center py-5 text-muted"><i class="bi bi-cart-x fs-1"></i><p class="mt-2">Your cart is empty.</p><a href="index.html" class="btn btn-primary">Continue Shopping</a></div>';
    if (summarySubtotal) summarySubtotal.textContent = '$0.00';
    if (summaryTotal) summaryTotal.textContent = '$0.00';
    return;
  }

  var subtotal = 0;
  var html = '';

  cart.forEach(function (item) {
    subtotal += item.price * item.qty;
    html += '<div class="d-flex align-items-center gap-3 py-3 border-bottom" data-id="' + item.id + '">' +
      '<img src="' + item.img + '" class="cart-item-img" alt="' + item.name + '">' +
      '<div class="flex-grow-1">' +
      '<p class="mb-1 fw-600">' + item.name + '</p>' +
      '<p class="text-primary fw-bold mb-0">$' + item.price.toFixed(2) + '</p>' +
      '</div>' +
      '<div class="d-flex align-items-center gap-2">' +
      '<button class="btn btn-outline-secondary qty-btn" onclick="changeQty(\'' + item.id + '\', -1)">-</button>' +
      '<span class="qty-val">' + item.qty + '</span>' +
      '<button class="btn btn-outline-secondary qty-btn" onclick="changeQty(\'' + item.id + '\', 1)">+</button>' +
      '</div>' +
      '<button class="btn btn-outline-danger btn-sm" onclick="removeItem(\'' + item.id + '\')"><i class="bi bi-trash"></i></button>' +
      '</div>';
  });

  container.innerHTML = html;

  var shipping = subtotal > 0 ? 5.00 : 0;
  var total = subtotal + shipping;

  if (summarySubtotal) summarySubtotal.textContent = '$' + subtotal.toFixed(2);
  if (summaryTotal) summaryTotal.textContent = '$' + total.toFixed(2);
}

function changeQty(id, delta) {
  var cart = getCart();
  var item = cart.find(function (i) { return i.id === id; });
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) {
    cart = cart.filter(function (i) { return i.id !== id; });
  }
  saveCart(cart);
  updateCartBadge();
  renderCart();
}

function removeItem(id) {
  var cart = getCart().filter(function (i) { return i.id !== id; });
  saveCart(cart);
  updateCartBadge();
  renderCart();
}

/* --- Product Thumbnail Switcher (Detail Page) --- */
function initThumbnails() {
  var thumbs = document.querySelectorAll('.thumbnail-img');
  var mainImg = document.getElementById('mainProductImg');
  if (!thumbs.length || !mainImg) return;

  thumbs.forEach(function (thumb) {
    thumb.addEventListener('click', function () {
      mainImg.src = this.src;
      thumbs.forEach(function (t) { t.classList.remove('active'); });
      this.classList.add('active');
    });
  });
}

/* --- Product Search Filter (Products Page) --- */
function initSearch() {
  var input = document.getElementById('productSearch');
  if (!input) return;

  input.addEventListener('input', function () {
    var query = this.value.toLowerCase();
    document.querySelectorAll('.product-card-wrapper').forEach(function (card) {
      var title = card.querySelector('.product-title');
      if (!title) return;
      card.classList.toggle('d-none', !title.textContent.toLowerCase().includes(query));
    });
  });
}

/* --- Init on DOM Ready --- */
document.addEventListener('DOMContentLoaded', function () {
  updateCartBadge();
  renderCart();
  initThumbnails();
  initSearch();
});
