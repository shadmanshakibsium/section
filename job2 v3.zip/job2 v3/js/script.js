// External JS - No Animation, Only Functionality
document.addEventListener('DOMContentLoaded', function() {
    console.log('Portfolio website loaded');

    // Contact form handler if exists
    const contactForm = document.getElementById('uniqueContactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            let name = document.getElementById('name').value;
            let email = document.getElementById('email').value;
            let msg = document.getElementById('message').value;

            if (!name || !email || !msg) {
                alert('Please fill all fields');
            } else if (!email.includes('@')) {
                alert('Valid email required');
            } else {
                alert(`Thanks ${name}! I'll reply within 24 hours.`);
                contactForm.reset();
            }
        });
    }
});



    // Portfolio filtering functionality (no animation, just pure JS)
    const filterButtons = document.querySelectorAll('.filter-btn');
    const projectItems = document.querySelectorAll('.project-item');

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons
            filterButtons.forEach(btn => {
                btn.classList.remove('btn-danger');
                btn.classList.add('btn-outline-danger');
            });
            button.classList.remove('btn-outline-danger');
            button.classList.add('btn-danger');

            const filterValue = button.getAttribute('data-filter');

            projectItems.forEach(item => {
                if (filterValue === 'all') {
                    item.style.display = 'block';
                } else {
                    if (item.getAttribute('data-category') === filterValue) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                }
            });
        });
    });




    setInterval(() => {
    document.getElementById('dt').textContent = new Date().toLocaleString();
}, 1000);