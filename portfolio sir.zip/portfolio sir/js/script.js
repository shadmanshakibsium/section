/* ============================================================
   Arafat Ahmed — Personal Portfolio
   External JavaScript (Bootstrap 5 + Custom)
   ============================================================ */
(function () {
  'use strict';

  /* ---------- Theme Toggle (Light / Dark) ---------- */
  const THEME_KEY = 'aa-portfolio-theme';
  const root = document.documentElement;

  function applyTheme(theme) {
    if (theme === 'dark') {
      root.setAttribute('data-theme', 'dark');
    } else {
      root.removeAttribute('data-theme');
    }
    document.querySelectorAll('[data-testid="theme-toggle-btn"]').forEach(btn => {
      const sun = btn.querySelector('.icon-sun');
      const moon = btn.querySelector('.icon-moon');
      if (theme === 'dark') {
        if (sun) sun.style.display = 'inline-block';
        if (moon) moon.style.display = 'none';
      } else {
        if (sun) sun.style.display = 'none';
        if (moon) moon.style.display = 'inline-block';
      }
    });
  }

  const savedTheme = localStorage.getItem(THEME_KEY) ||
    (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  applyTheme(savedTheme);

  document.addEventListener('click', function (e) {
    const btn = e.target.closest('[data-testid="theme-toggle-btn"]');
    if (!btn) return;
    const current = root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
    const next = current === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
  });

  /* ---------- Active Nav Link ---------- */
  const path = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  document.querySelectorAll('.navbar .nav-link').forEach(link => {
    const target = (link.getAttribute('href') || '').toLowerCase();
    if (target === path || (path === '' && target === 'index.html')) {
      link.classList.add('active');
    }
  });

  /* ---------- Search (Document search across pages) ---------- */
  const SEARCH_INDEX = [
    { title: 'Home', url: 'index.html', tags: 'home landing intro hero arafat web developer freelancer' },
    { title: 'About Me', url: 'about.html', tags: 'about bio story skills experience timeline education' },
    { title: 'Portfolio Projects', url: 'portfolio.html', tags: 'portfolio works projects case studies clients' },
    { title: 'Services', url: 'services.html', tags: 'services web design development seo branding ui ux' },
    { title: 'Contact', url: 'contact.html', tags: 'contact email phone form message location address' },
    { title: 'Web Design Service', url: 'services.html#web-design', tags: 'web design ui ux figma' },
    { title: 'Web Development Service', url: 'services.html#web-development', tags: 'web development html css js react bootstrap' },
    { title: 'SEO Service', url: 'services.html#seo', tags: 'seo search engine optimization ranking' },
    { title: 'E-commerce Project', url: 'portfolio.html', tags: 'ecommerce shop store online' },
    { title: 'Branding & Identity', url: 'services.html#branding', tags: 'branding logo identity' },
    { title: 'Skills & Tools', url: 'about.html#skills', tags: 'skills html css javascript react bootstrap tailwind' },
    { title: 'Get a Quote', url: 'contact.html', tags: 'quote price hire freelance' }
  ];

  const searchInput = document.querySelector('[data-testid="search-input"]');
  const searchResults = document.querySelector('[data-testid="search-results"]');

  function renderSearch(q) {
    if (!searchResults) return;
    const term = q.trim().toLowerCase();
    if (!term) { searchResults.classList.remove('show'); searchResults.innerHTML = ''; return; }
    const matches = SEARCH_INDEX.filter(item =>
      item.title.toLowerCase().includes(term) || item.tags.toLowerCase().includes(term)
    ).slice(0, 6);
    if (matches.length === 0) {
      searchResults.innerHTML = '<div class="empty">No results for "' + escapeHtml(q) + '"</div>';
    } else {
      searchResults.innerHTML = matches.map(m =>
        '<a href="' + m.url + '" data-testid="search-result-item">' + escapeHtml(m.title) + '</a>'
      ).join('');
    }
    searchResults.classList.add('show');
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', e => renderSearch(e.target.value));
    searchInput.addEventListener('focus', e => { if (e.target.value) renderSearch(e.target.value); });
    document.addEventListener('click', e => {
      if (!e.target.closest('.search-wrap')) {
        searchResults && searchResults.classList.remove('show');
      }
    });
  }

  /* ---------- Skill Bar Animation on view ---------- */
  const skillBars = document.querySelectorAll('.skill-row .fill');
  if (skillBars.length && 'IntersectionObserver' in window) {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const fill = entry.target;
          const val = fill.getAttribute('data-percent') || '0';
          fill.style.width = val + '%';
          obs.unobserve(fill);
        }
      });
    }, { threshold: 0.4 });
    skillBars.forEach(b => { b.style.width = '0%'; obs.observe(b); });
  }

  /* ---------- Reveal on scroll ---------- */
  const reveals = document.querySelectorAll('.reveal');
  if (reveals.length && 'IntersectionObserver' in window) {
    const ro = new IntersectionObserver(entries => {
      entries.forEach(en => {
        if (en.isIntersecting) {
          en.target.classList.add('is-visible');
          ro.unobserve(en.target);
        }
      });
    }, { threshold: 0.12 });
    reveals.forEach(r => ro.observe(r));
  } else {
    reveals.forEach(r => r.classList.add('is-visible'));
  }

  /* ---------- Portfolio Filter ---------- */
  const filterBtns = document.querySelectorAll('[data-testid^="filter-btn-"]');
  const portfolioItems = document.querySelectorAll('[data-category]');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.getAttribute('data-filter');
      portfolioItems.forEach(item => {
        const itemCat = item.getAttribute('data-category');
        if (cat === 'all' || itemCat === cat) {
          item.style.display = '';
        } else {
          item.style.display = 'none';
        }
      });
    });
  });

  /* ---------- Contact form validation ---------- */
  const form = document.querySelector('[data-testid="contact-form"]');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (!form.checkValidity()) {
        form.classList.add('was-validated');
        return;
      }
      // Simulate submission (frontend-only)
      const alertBox = document.querySelector('[data-testid="form-success-alert"]');
      if (alertBox) {
        alertBox.style.display = 'block';
        alertBox.textContent = 'Thank you! Your message has been received. I will get back within 24 hours.';
      }
      form.reset();
      form.classList.remove('was-validated');
      setTimeout(() => { if (alertBox) alertBox.style.display = 'none'; }, 6000);
    });
  }

  /* ---------- Year in footer ---------- */
  document.querySelectorAll('[data-testid="footer-year"]').forEach(el => {
    el.textContent = new Date().getFullYear();
  });

  /* ---------- Smooth anchor offset ---------- */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', function (e) {
      const id = this.getAttribute('href');
      if (id.length > 1) {
        const tgt = document.querySelector(id);
        if (tgt) { e.preventDefault(); window.scrollTo({ top: tgt.offsetTop - 80, behavior: 'smooth' }); }
      }
    });
  });
})();