// ===== LIVE DATE & TIME IN FOOTER =====
function updateClock() {
  const el = document.getElementById('live-datetime');
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleString('en-US', {
    weekday: 'short', year: 'numeric', month: 'short',
    day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
}
setInterval(updateClock, 1000);
updateClock();

// ===== CONTACT FORM VALIDATION =====
(function () {
  const form = document.getElementById('contactForm');
  if (!form) return;

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (!form.checkValidity()) {
      form.classList.add('was-validated');
      return;
    }
    // Success feedback
    form.classList.remove('was-validated');
    form.reset();
    const msg = document.getElementById('form-success');
    if (msg) {
      msg.classList.remove('d-none');
      setTimeout(() => msg.classList.add('d-none'), 4000);
    }
  });
})();
